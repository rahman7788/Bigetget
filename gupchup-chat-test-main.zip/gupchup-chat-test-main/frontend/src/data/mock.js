// GupShup Chat - Mock/Helper Data

// Friend Request Status
export const REQUEST_STATUS = {
  PENDING: 'pending',
  ACCEPTED: 'accepted',
  REJECTED: 'rejected'
};

// User Status Types
export const USER_STATUS = {
  ONLINE: 'online',
  OFFLINE: 'offline',
  AWAY: 'away',
  BUSY: 'busy'
};

// Message Types
export const MESSAGE_TYPES = {
  TEXT: 'text',
  IMAGE: 'image',
  VIDEO: 'video'
};

// App Info
export const APP_INFO = {
  name: 'GupShup Chat',
  tagline: 'Real-time chat with friends',
  developers: [
    { name: 'Rahman Ahmed', role: 'Developer' },
    { name: 'Ghulam Murtaza', role: 'Developer' }
  ],
  version: '1.0.0'
};
