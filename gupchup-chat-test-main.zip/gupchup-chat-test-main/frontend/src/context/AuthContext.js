import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [socket, setSocket] = useState(null);
  const [loading, setLoading] = useState(true);

  const initSocket = (authToken) => {
    if (socket) socket.disconnect();
    
    const newSocket = io(BACKEND_URL, {
      auth: { token: authToken },
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000
    });
    
    newSocket.on('connect', () => console.log('Socket connected'));
    newSocket.on('disconnect', () => console.log('Socket disconnected'));
    
    setSocket(newSocket);
    return newSocket;
  };

  useEffect(() => {
    const savedToken = localStorage.getItem('gupshup_token');
    const savedUser = localStorage.getItem('gupshup_user');
    
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
      axios.defaults.headers.common['Authorization'] = `Bearer ${savedToken}`;
      initSocket(savedToken);
    }
    setLoading(false);
    
    return () => { if (socket) socket.disconnect(); };
  }, []);

  // Simple signup without OTP
  const signup = async (email, password, username) => {
    try {
      const response = await axios.post(`${API}/auth/signup`, {
        email, password, username
      });
      const { user: userData, token: authToken } = response.data;
      
      setUser(userData);
      setToken(authToken);
      localStorage.setItem('gupshup_token', authToken);
      localStorage.setItem('gupshup_user', JSON.stringify(userData));
      axios.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
      initSocket(authToken);
      
      return { success: true, user: userData };
    } catch (error) {
      return { success: false, error: error.response?.data?.detail || 'Signup failed' };
    }
  };

  const login = async (email, password) => {
    try {
      const response = await axios.post(`${API}/auth/login`, { email, password });
      const { user: userData, token: authToken } = response.data;
      
      setUser(userData);
      setToken(authToken);
      localStorage.setItem('gupshup_token', authToken);
      localStorage.setItem('gupshup_user', JSON.stringify(userData));
      axios.defaults.headers.common['Authorization'] = `Bearer ${authToken}`;
      initSocket(authToken);
      
      return { success: true, user: userData };
    } catch (error) {
      return { success: false, error: error.response?.data?.detail || 'Invalid email or password' };
    }
  };

  const updateProfile = async (data) => {
    try {
      const response = await axios.put(`${API}/auth/profile`, data);
      const updatedUser = response.data;
      setUser(updatedUser);
      localStorage.setItem('gupshup_user', JSON.stringify(updatedUser));
      return { success: true, user: updatedUser };
    } catch (error) {
      return { success: false, error: error.response?.data?.detail || 'Update failed' };
    }
  };

  const uploadAvatar = async (file) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await axios.post(`${API}/auth/upload-avatar`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      const updatedUser = { ...user, avatar: response.data.avatar };
      setUser(updatedUser);
      localStorage.setItem('gupshup_user', JSON.stringify(updatedUser));
      return { success: true, avatar: response.data.avatar };
    } catch (error) {
      return { success: false, error: 'Upload failed' };
    }
  };

  const logout = async () => {
    try { await axios.post(`${API}/auth/logout`); } catch (e) {}
    if (socket) socket.disconnect();
    setSocket(null);
    setUser(null);
    setToken(null);
    localStorage.removeItem('gupshup_token');
    localStorage.removeItem('gupshup_user');
    delete axios.defaults.headers.common['Authorization'];
  };

  return (
    <AuthContext.Provider value={{ 
      user, token, socket, loading,
      login, logout, signup,
      updateProfile, uploadAvatar
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
