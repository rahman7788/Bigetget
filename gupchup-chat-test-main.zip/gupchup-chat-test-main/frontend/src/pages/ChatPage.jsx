import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { ScrollArea } from '../components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Switch } from '../components/ui/switch';
import GupShupLogo, { GupShupLogoText } from '../components/GupShupLogo';
import { 
  Search, Send, Phone, Video, MoreVertical, ArrowLeft, LogOut, 
  User, UserPlus, X, Image, Camera, Check, CheckCheck, MessageCircle, Bell, Info,
  Plus, PhoneIncoming, PhoneOutgoing, PhoneMissed, Clock, Mic, MicOff,
  Moon, Smile, Circle, Sparkles, VideoOff, PhoneOff, Eye, EyeOff, Palette, ImageIcon
} from 'lucide-react';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator
} from '../components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import EmojiPicker from 'emoji-picker-react';
import axios from 'axios';
import Peer from 'simple-peer';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const REACTIONS = [
  { emoji: '❤️', name: 'love' },
  { emoji: '👍', name: 'like' },
  { emoji: '😂', name: 'laugh' },
  { emoji: '😮', name: 'wow' },
  { emoji: '😢', name: 'sad' },
  { emoji: '🔥', name: 'fire' }
];

// 10 Pre-built chat themes
const CHAT_THEMES = [
  { id: 'default', name: 'Default', bg: 'bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50', darkBg: 'bg-gray-900' },
  { id: 'ocean', name: 'Ocean', bg: 'bg-gradient-to-br from-cyan-100 via-blue-100 to-indigo-100', darkBg: 'bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900' },
  { id: 'sunset', name: 'Sunset', bg: 'bg-gradient-to-br from-orange-100 via-pink-100 to-rose-100', darkBg: 'bg-gradient-to-br from-orange-950 via-pink-950 to-rose-950' },
  { id: 'forest', name: 'Forest', bg: 'bg-gradient-to-br from-green-100 via-emerald-100 to-teal-100', darkBg: 'bg-gradient-to-br from-green-950 via-emerald-950 to-teal-950' },
  { id: 'lavender', name: 'Lavender', bg: 'bg-gradient-to-br from-purple-100 via-violet-100 to-fuchsia-100', darkBg: 'bg-gradient-to-br from-purple-950 via-violet-950 to-fuchsia-950' },
  { id: 'midnight', name: 'Midnight', bg: 'bg-gradient-to-br from-slate-200 via-gray-200 to-zinc-200', darkBg: 'bg-gradient-to-br from-slate-950 via-gray-950 to-zinc-950' },
  { id: 'rose', name: 'Rose Gold', bg: 'bg-gradient-to-br from-rose-100 via-pink-100 to-red-100', darkBg: 'bg-gradient-to-br from-rose-950 via-pink-950 to-red-950' },
  { id: 'mint', name: 'Mint Fresh', bg: 'bg-gradient-to-br from-teal-100 via-cyan-100 to-sky-100', darkBg: 'bg-gradient-to-br from-teal-950 via-cyan-950 to-sky-950' },
  { id: 'golden', name: 'Golden Hour', bg: 'bg-gradient-to-br from-amber-100 via-yellow-100 to-orange-100', darkBg: 'bg-gradient-to-br from-amber-950 via-yellow-950 to-orange-950' },
  { id: 'cosmic', name: 'Cosmic', bg: 'bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100', darkBg: 'bg-gradient-to-br from-indigo-950 via-purple-950 to-pink-950' }
];

// Notification sound
const NOTIFICATION_SOUND = 'data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//tQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAABhgC7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7u7//////////////////////////////////////////////////////////////////8AAAAATGF2YzU4LjEzAAAAAAAAAAAAAAAAJAAAAAAAAAAAAYZNFqL/AAAAAAAAAAAAAAAAAAAAAP/7UMQAA8AAAaQAAAAgAAA0gAAABExBTUUzLjEwMFVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tQxBOAAAGkAAAAIAAANIAAAARVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==';

const requestNotificationPermission = async () => {
  if ('Notification' in window && Notification.permission === 'default') {
    await Notification.requestPermission();
  }
};

const showNotification = (title, body, icon) => {
  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(title, { body, icon, badge: icon });
  }
};

const playNotificationSound = () => {
  const audio = new Audio(NOTIFICATION_SOUND);
  audio.volume = 0.5;
  audio.play().catch(() => {});
};

const ChatPage = () => {
  const { user, socket, logout, uploadAvatar, updateProfile } = useAuth();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  
  const [activeTab, setActiveTab] = useState('chats');
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showMobileChat, setShowMobileChat] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showRequests, setShowRequests] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [showStatusView, setShowStatusView] = useState(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [showStatusViews, setShowStatusViews] = useState(false);
  const [searchUsers, setSearchUsers] = useState([]);
  const [friendRequests, setFriendRequests] = useState([]);
  const [typing, setTyping] = useState(null);
  const [sendingRequest, setSendingRequest] = useState({});
  const [statuses, setStatuses] = useState([]);
  const [myStatus, setMyStatus] = useState(null);
  const [callHistory, setCallHistory] = useState([]);
  const [selectedReaction, setSelectedReaction] = useState(null);
  const [statusViewers, setStatusViewers] = useState([]);
  
  // User settings
  const [invisibleMode, setInvisibleMode] = useState(false);
  const [chatTheme, setChatTheme] = useState('default');
  const [customWallpaper, setCustomWallpaper] = useState(null);
  
  // Voice recording states
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [mediaRecorder, setMediaRecorder] = useState(null);
  
  // Call states
  const [callState, setCallState] = useState(null);
  const [callType, setCallType] = useState(null);
  const [callContact, setCallContact] = useState(null);
  const [localStream, setLocalStream] = useState(null);
  const [remoteStream, setRemoteStream] = useState(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  
  const messagesEndRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);
  const mediaInputRef = useRef(null);
  const statusInputRef = useRef(null);
  const wallpaperInputRef = useRef(null);
  const recordingIntervalRef = useRef(null);
  const inputRef = useRef(null);
  const peerRef = useRef(null);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const callDurationRef = useRef(null);

  useEffect(() => {
    requestNotificationPermission();
  }, []);

  // Load user settings
  useEffect(() => {
    if (user) {
      setInvisibleMode(user.invisible_mode || false);
      setChatTheme(user.chat_theme || 'default');
      setCustomWallpaper(user.chat_wallpaper || null);
    }
  }, [user]);

  // Socket listeners
  useEffect(() => {
    if (!socket) return;
    
    const handleNewMessage = (message) => {
      if (message.sender_id !== user?.id) {
        playNotificationSound();
        if (document.hidden) {
          showNotification(
            `New message from ${message.sender_username || 'Someone'}`,
            message.text || '📎 Media message',
            message.sender_avatar
          );
        }
      }
      
      if (selectedContact && (message.sender_id === selectedContact.id || message.receiver_id === selectedContact.id)) {
        setMessages(prev => [...prev, message]);
        socket.emit('mark_read', { contact_id: message.sender_id });
      }
      
      setContacts(prev => prev.map(c => {
        if (c.id === message.sender_id) {
          return {
            ...c,
            last_message: message.text || (message.message_type === 'image' ? '📷 Photo' : message.message_type === 'audio' ? '🎤 Voice' : '🎥 Video'),
            last_message_time: 'Just now',
            unread_count: selectedContact?.id === c.id ? 0 : c.unread_count + 1
          };
        }
        return c;
      }));
    };

    const handleUserStatus = ({ user_id, status }) => {
      setContacts(prev => prev.map(c => c.id === user_id ? { ...c, status } : c));
      if (selectedContact?.id === user_id) {
        setSelectedContact(prev => prev ? { ...prev, status } : null);
      }
    };

    const handleTyping = ({ user_id, typing: isTyping }) => {
      if (selectedContact?.id === user_id) setTyping(isTyping ? user_id : null);
    };

    const handleFriendRequest = (request) => {
      playNotificationSound();
      showNotification('New Friend Request', `${request.sender_username} wants to be your friend!`, request.sender_avatar);
      setFriendRequests(prev => [request, ...prev]);
    };
    
    const handleFriendRequestAccepted = () => fetchContacts();

    const handleIncomingCall = (data) => {
      playNotificationSound();
      setCallContact({
        id: data.caller_id,
        username: data.caller_username,
        avatar: data.caller_avatar
      });
      setCallType(data.call_type);
      setCallState('incoming');
      peerRef.current = { signalData: data.signal_data };
      showNotification(
        `Incoming ${data.call_type} call`,
        `${data.caller_username} is calling you`,
        data.caller_avatar
      );
    };

    const handleCallAnswered = (data) => {
      if (peerRef.current && peerRef.current.signal) {
        peerRef.current.signal(data.signal_data);
      }
      setCallState('connected');
      startCallTimer();
    };

    const handleCallEnded = () => endCall();
    const handleCallRejected = () => endCall();

    const handleIceCandidate = (data) => {
      if (peerRef.current && peerRef.current.signal) {
        peerRef.current.signal(data.candidate);
      }
    };

    const handleMessageRead = ({ user_id }) => {
      if (selectedContact?.id === user_id) {
        setMessages(prev => prev.map(m => m.type === 'sent' ? { ...m, read: true } : m));
      }
    };

    const handleReaction = ({ message_id, reaction, user_id }) => {
      setMessages(prev => prev.map(m => 
        m.id === message_id ? { ...m, reactions: [...(m.reactions || []), { reaction, user_id }] } : m
      ));
    };

    const handleNewContact = () => fetchContacts();
    
    const handleStatusViewed = (data) => {
      if (myStatus && data.status_id === myStatus.id) {
        setStatusViewers(prev => [...prev, {
          user_id: data.viewer_id,
          username: data.viewer_username,
          avatar: data.viewer_avatar
        }]);
      }
    };

    socket.on('new_message', handleNewMessage);
    socket.on('user_status', handleUserStatus);
    socket.on('typing', handleTyping);
    socket.on('friend_request', handleFriendRequest);
    socket.on('friend_request_accepted', handleFriendRequestAccepted);
    socket.on('incoming_call', handleIncomingCall);
    socket.on('call_answered', handleCallAnswered);
    socket.on('call_ended', handleCallEnded);
    socket.on('call_rejected', handleCallRejected);
    socket.on('ice_candidate', handleIceCandidate);
    socket.on('messages_read', handleMessageRead);
    socket.on('message_reaction', handleReaction);
    socket.on('new_contact', handleNewContact);
    socket.on('status_viewed', handleStatusViewed);

    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('user_status', handleUserStatus);
      socket.off('typing', handleTyping);
      socket.off('friend_request', handleFriendRequest);
      socket.off('friend_request_accepted', handleFriendRequestAccepted);
      socket.off('incoming_call', handleIncomingCall);
      socket.off('call_answered', handleCallAnswered);
      socket.off('call_ended', handleCallEnded);
      socket.off('call_rejected', handleCallRejected);
      socket.off('ice_candidate', handleIceCandidate);
      socket.off('messages_read', handleMessageRead);
      socket.off('message_reaction', handleReaction);
      socket.off('new_contact', handleNewContact);
      socket.off('status_viewed', handleStatusViewed);
    };
  }, [socket, selectedContact, user, myStatus]);

  const fetchContacts = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/contacts`);
      setContacts(response.data);
    } catch (error) { console.error('Error:', error); }
  }, []);

  const fetchFriendRequests = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/friend-requests`);
      setFriendRequests(response.data);
    } catch (error) { console.error('Error:', error); }
  }, []);

  const fetchStatuses = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/statuses`);
      setStatuses(response.data.others || []);
      setMyStatus(response.data.my_status);
      if (response.data.my_status?.views) {
        setStatusViewers(response.data.my_status.views);
      }
    } catch (error) { console.error('Error:', error); }
  }, []);

  const fetchCallHistory = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/calls/history`);
      setCallHistory(response.data);
    } catch (error) { console.error('Error:', error); }
  }, []);

  useEffect(() => {
    if (!user) navigate('/');
    else {
      fetchContacts();
      fetchFriendRequests();
      fetchStatuses();
      fetchCallHistory();
    }
  }, [user, navigate, fetchContacts, fetchFriendRequests, fetchStatuses, fetchCallHistory]);

  useEffect(() => {
    const fetchMessages = async () => {
      if (selectedContact) {
        try {
          const response = await axios.get(`${API}/messages/${selectedContact.id}`);
          setMessages(response.data);
        } catch (error) { console.error('Error:', error); }
      }
    };
    fetchMessages();
  }, [selectedContact]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const startCallTimer = () => {
    setCallDuration(0);
    callDurationRef.current = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);
  };

  const formatCallDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Toggle invisible mode
  const toggleInvisibleMode = async () => {
    const newValue = !invisibleMode;
    setInvisibleMode(newValue);
    try {
      await axios.put(`${API}/auth/profile`, { invisible_mode: newValue });
    } catch (error) {
      console.error('Error:', error);
      setInvisibleMode(!newValue);
    }
  };

  // Change chat theme
  const changeChatTheme = async (themeId) => {
    setChatTheme(themeId);
    setCustomWallpaper(null);
    try {
      await axios.put(`${API}/auth/profile`, { chat_theme: themeId, chat_wallpaper: null });
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Upload custom wallpaper
  const uploadWallpaper = async (file) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await axios.post(`${API}/auth/upload-wallpaper`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setCustomWallpaper(response.data.wallpaper);
      setChatTheme('custom');
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // View status and record view
  const viewStatus = async (status) => {
    setShowStatusView(status);
    try {
      await axios.post(`${API}/statuses/${status.id}/view`);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Voice Recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks = [];
      
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        stream.getTracks().forEach(track => track.stop());
        await sendVoiceMessage(blob);
      };
      
      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
      setRecordingTime(0);
      
      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Microphone access denied. Please allow microphone access.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
    }
    setIsRecording(false);
    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current);
    }
  };

  const cancelRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
      mediaRecorder.stop();
    }
    setIsRecording(false);
    if (recordingIntervalRef.current) {
      clearInterval(recordingIntervalRef.current);
    }
  };

  const sendVoiceMessage = async (blob) => {
    if (!selectedContact) return;
    try {
      const formData = new FormData();
      formData.append('file', blob, 'voice.webm');
      const response = await axios.post(
        `${API}/messages/media?receiver_id=${selectedContact.id}&message_type=audio`,
        formData,
        { headers: { 'Content-Type': 'multipart/form-data' } }
      );
      setMessages(prev => [...prev, response.data]);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // Call Functions
  const initiateCall = async (contact, type) => {
    try {
      const constraints = type === 'video' ? { video: true, audio: true } : { audio: true };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setLocalStream(stream);
      setCallContact(contact);
      setCallType(type);
      setCallState('calling');
      
      if (localVideoRef.current && type === 'video') {
        localVideoRef.current.srcObject = stream;
      }
      
      const peer = new Peer({ initiator: true, trickle: false, stream });
      
      peer.on('signal', (signalData) => {
        socket.emit('call_user', { receiver_id: contact.id, call_type: type, signal_data: signalData });
      });
      
      peer.on('stream', (remoteStream) => {
        setRemoteStream(remoteStream);
        if (remoteVideoRef.current) remoteVideoRef.current.srcObject = remoteStream;
      });
      
      peer.on('error', () => endCall());
      peerRef.current = peer;
      
      setCallHistory(prev => [{
        id: Date.now().toString(),
        contact: { username: contact.username, avatar: contact.avatar, id: contact.id },
        type: 'outgoing', call_type: type,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        status: 'completed'
      }, ...prev]);
    } catch (error) {
      console.error('Error:', error);
      alert('Could not access camera/microphone.');
    }
  };

  const answerCall = async () => {
    try {
      const constraints = callType === 'video' ? { video: true, audio: true } : { audio: true };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setLocalStream(stream);
      
      if (localVideoRef.current && callType === 'video') {
        localVideoRef.current.srcObject = stream;
      }
      
      const peer = new Peer({ initiator: false, trickle: false, stream });
      
      peer.on('signal', (signalData) => {
        socket.emit('answer_call', { caller_id: callContact.id, signal_data: signalData });
      });
      
      peer.on('stream', (remoteStream) => {
        setRemoteStream(remoteStream);
        if (remoteVideoRef.current) remoteVideoRef.current.srcObject = remoteStream;
      });
      
      peer.on('error', () => endCall());
      
      if (peerRef.current?.signalData) peer.signal(peerRef.current.signalData);
      peerRef.current = peer;
      setCallState('connected');
      startCallTimer();
    } catch (error) {
      console.error('Error:', error);
      rejectCall();
    }
  };

  const rejectCall = () => {
    socket.emit('reject_call', { caller_id: callContact?.id });
    endCall();
  };

  const endCall = () => {
    if (peerRef.current?.destroy) peerRef.current.destroy();
    peerRef.current = null;
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
      setLocalStream(null);
    }
    if (callDurationRef.current) clearInterval(callDurationRef.current);
    if (callContact && callState === 'connected') {
      socket.emit('end_call', { other_user_id: callContact.id });
    }
    setRemoteStream(null);
    setCallState(null);
    setCallType(null);
    setCallContact(null);
    setCallDuration(0);
    setIsMuted(false);
    setIsVideoOff(false);
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => { track.enabled = !track.enabled; });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => { track.enabled = !track.enabled; });
      setIsVideoOff(!isVideoOff);
    }
  };

  const handleSelectContact = (contact) => {
    setSelectedContact(contact);
    setShowMobileChat(true);
    setContacts(prev => prev.map(c => c.id === contact.id ? { ...c, unread_count: 0 } : c));
  };

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedContact) return;

    try {
      const response = await axios.post(`${API}/messages`, {
        receiver_id: selectedContact.id,
        text: newMessage,
        message_type: 'text'
      });
      setMessages(prev => [...prev, response.data]);
      setNewMessage('');
      setShowEmojiPicker(false);
      setContacts(prev => prev.map(c =>
        c.id === selectedContact.id ? { ...c, last_message: newMessage, last_message_time: 'Just now' } : c
      ));
    } catch (error) { console.error('Error:', error); }
  };

  const handleSendMedia = async (file, type) => {
    if (!selectedContact) return;
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await axios.post(
        `${API}/messages/media?receiver_id=${selectedContact.id}&message_type=${type}`,
        formData, { headers: { 'Content-Type': 'multipart/form-data' } }
      );
      setMessages(prev => [...prev, response.data]);
    } catch (error) { console.error('Error:', error); }
  };

  const handleTypingIndicator = () => {
    if (socket && selectedContact) {
      socket.emit('typing', { contact_id: selectedContact.id, typing: true });
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => {
        socket.emit('typing', { contact_id: selectedContact.id, typing: false });
      }, 2000);
    }
  };

  const handleEmojiClick = (emojiData) => {
    setNewMessage(prev => prev + emojiData.emoji);
    inputRef.current?.focus();
  };

  const handleSearchUsers = async (query) => {
    if (query.length < 1) { setSearchUsers([]); return; }
    try {
      const response = await axios.get(`${API}/users/search?q=${query}`);
      setSearchUsers(response.data);
    } catch (error) { console.error('Error:', error); }
  };

  const handleSendFriendRequest = async (userId) => {
    setSendingRequest(prev => ({ ...prev, [userId]: true }));
    try {
      await axios.post(`${API}/friend-requests`, { receiver_id: userId });
      setSendingRequest(prev => ({ ...prev, [userId]: 'sent' }));
    } catch (error) {
      setSendingRequest(prev => ({ ...prev, [userId]: false }));
    }
  };

  const handleRespondToRequest = async (requestId, action) => {
    try {
      await axios.put(`${API}/friend-requests/${requestId}?action=${action}`);
      setFriendRequests(prev => prev.filter(r => r.id !== requestId));
      if (action === 'accept') fetchContacts();
    } catch (error) { console.error('Error:', error); }
  };

  const handleAddStatus = async (file) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      await axios.post(`${API}/statuses`, formData, { headers: { 'Content-Type': 'multipart/form-data' } });
      fetchStatuses();
    } catch (error) { console.error('Error:', error); }
  };

  const handleReaction = async (messageId, reaction) => {
    try {
      await axios.post(`${API}/messages/${messageId}/reaction`, { reaction });
      setMessages(prev => prev.map(m => 
        m.id === messageId ? { ...m, reactions: [...(m.reactions || []), { reaction, user_id: user.id }] } : m
      ));
    } catch (error) { console.error('Error:', error); }
    setSelectedReaction(null);
  };

  const handleLogout = async () => { await logout(); navigate('/'); };

  const filteredContacts = contacts.filter(c => c.username.toLowerCase().includes(searchQuery.toLowerCase()));

  const formatRecordingTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Get current theme background
  const getThemeBg = () => {
    if (customWallpaper) return '';
    const theme = CHAT_THEMES.find(t => t.id === chatTheme) || CHAT_THEMES[0];
    return isDark ? theme.darkBg : theme.bg;
  };

  if (!user) return null;

  const bgClass = isDark ? 'bg-gray-900' : 'bg-gradient-to-br from-violet-50 via-purple-50 to-indigo-50';
  const cardClass = isDark ? 'bg-gray-800' : 'bg-white';
  const textClass = isDark ? 'text-white' : 'text-gray-900';
  const mutedClass = isDark ? 'text-gray-400' : 'text-gray-500';
  const borderClass = isDark ? 'border-gray-700' : 'border-violet-100';
  const hoverClass = isDark ? 'hover:bg-gray-700' : 'hover:bg-violet-50';

  // Call Modal
  const CallModal = () => {
    if (!callState) return null;
    return (
      <div className="fixed inset-0 bg-black/90 z-50 flex flex-col items-center justify-center">
        {callType === 'video' && callState === 'connected' && (
          <>
            <video ref={remoteVideoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover" />
            <video ref={localVideoRef} autoPlay playsInline muted className="absolute bottom-24 right-4 w-32 h-44 object-cover rounded-2xl border-2 border-white shadow-xl" />
          </>
        )}
        <div className={`text-center z-10 ${callType === 'video' && callState === 'connected' ? 'absolute top-8' : ''}`}>
          {(callState !== 'connected' || callType === 'voice') && (
            <div className="relative inline-block mb-6">
              <Avatar className="h-32 w-32 ring-4 ring-violet-400">
                <AvatarImage src={callContact?.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white text-3xl">
                  {callContact?.username?.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {callState === 'calling' && <div className="absolute inset-0 rounded-full border-4 border-violet-400 animate-ping" />}
              {callState === 'incoming' && <div className="absolute inset-0 rounded-full border-4 border-green-400 animate-ping" />}
            </div>
          )}
          <h2 className="text-2xl font-bold text-white mb-2">{callContact?.username}</h2>
          <p className="text-white/70">
            {callState === 'calling' && 'Calling...'}
            {callState === 'incoming' && `Incoming ${callType} call...`}
            {callState === 'connected' && formatCallDuration(callDuration)}
          </p>
        </div>
        <div className={`flex items-center gap-4 ${callType === 'video' && callState === 'connected' ? 'absolute bottom-8' : 'mt-12'}`}>
          {callState === 'connected' && (
            <>
              <Button variant="ghost" size="icon" onClick={toggleMute}
                className={`h-14 w-14 rounded-full ${isMuted ? 'bg-red-500' : 'bg-white/20'} text-white hover:bg-white/30`}>
                {isMuted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
              </Button>
              {callType === 'video' && (
                <Button variant="ghost" size="icon" onClick={toggleVideo}
                  className={`h-14 w-14 rounded-full ${isVideoOff ? 'bg-red-500' : 'bg-white/20'} text-white hover:bg-white/30`}>
                  {isVideoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
                </Button>
              )}
            </>
          )}
          {callState === 'incoming' && (
            <Button onClick={answerCall} className="h-16 w-16 rounded-full bg-green-500 hover:bg-green-600 text-white">
              <Phone className="h-7 w-7" />
            </Button>
          )}
          <Button onClick={callState === 'incoming' ? rejectCall : endCall} className="h-16 w-16 rounded-full bg-red-500 hover:bg-red-600 text-white">
            <PhoneOff className="h-7 w-7" />
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className={`h-screen ${bgClass} flex`}>
      <CallModal />
      
      {/* Sidebar */}
      <div className={`${showMobileChat ? 'hidden md:flex' : 'flex'} flex-col w-full md:w-[420px] ${cardClass} md:border-r ${borderClass} shadow-xl`}>
        {/* Header */}
        <div className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 text-white p-4">
          <div className="flex items-center justify-between mb-4">
            <GupShupLogoText size="sm" dark />
            <div className="flex items-center gap-1">
              {/* Invisible Mode Toggle */}
              <Button variant="ghost" size="icon" 
                className={`text-white hover:bg-white/20 rounded-full ${invisibleMode ? 'bg-white/20' : ''}`}
                onClick={toggleInvisibleMode}
                title={invisibleMode ? 'Invisible Mode ON' : 'Invisible Mode OFF'}>
                {invisibleMode ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 rounded-full relative"
                onClick={() => setShowRequests(true)}>
                <Bell className="h-5 w-5" />
                {friendRequests.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-pink-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                    {friendRequests.length}
                  </span>
                )}
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 rounded-full">
                    <MoreVertical className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-52 rounded-xl">
                  <DropdownMenuItem className="cursor-pointer rounded-lg" onClick={() => setShowProfile(true)}>
                    <User className="mr-2 h-4 w-4" /><span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer rounded-lg" onClick={() => setShowThemeSelector(true)}>
                    <Palette className="mr-2 h-4 w-4" /><span>Chat Themes</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer rounded-lg">
                    <div className="flex items-center justify-between w-full">
                      <span className="flex items-center"><Moon className="mr-2 h-4 w-4" />Dark Mode</span>
                      <Switch checked={isDark} onCheckedChange={toggleTheme} />
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer rounded-lg">
                    <div className="flex items-center justify-between w-full">
                      <span className="flex items-center"><EyeOff className="mr-2 h-4 w-4" />Invisible</span>
                      <Switch checked={invisibleMode} onCheckedChange={toggleInvisibleMode} />
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="cursor-pointer rounded-lg" onClick={() => setShowAbout(true)}>
                    <Info className="mr-2 h-4 w-4" /><span>About</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="cursor-pointer text-red-500 rounded-lg" onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" /><span>Logout</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
          
          {activeTab === 'chats' && (
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/60" />
              <Input
                placeholder="Search chats..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 bg-white/20 border-0 text-white placeholder:text-white/60 focus:ring-2 focus:ring-white/30 rounded-full h-10"
              />
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-hidden relative">
          {/* Chats Tab */}
          {activeTab === 'chats' && (
            <ScrollArea className="h-full">
              <div className="pb-20">
                {filteredContacts.length === 0 ? (
                  <div className={`text-center py-16 ${mutedClass}`}>
                    <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center">
                      <MessageCircle className="h-10 w-10 text-violet-400" />
                    </div>
                    <p className="font-medium text-lg">No chats yet</p>
                    <p className="text-sm mt-1">Add friends to start chatting!</p>
                    <Button className="mt-4 bg-gradient-to-r from-violet-500 to-purple-500 rounded-full" onClick={() => setShowAddContact(true)}>
                      <UserPlus className="h-4 w-4 mr-2" /> Add Friend
                    </Button>
                  </div>
                ) : (
                  filteredContacts.map((contact) => (
                    <div key={contact.id} onClick={() => handleSelectContact(contact)}
                      className={`flex items-center gap-3 px-4 py-3 ${hoverClass} cursor-pointer transition-all border-b ${borderClass} group`}>
                      <div className="relative flex-shrink-0">
                        <Avatar className="h-14 w-14 ring-2 ring-violet-100">
                          <AvatarImage src={contact.avatar} />
                          <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white font-semibold text-lg">
                            {contact.username.slice(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        {contact.status === 'online' && !contact.invisible_mode && (
                          <span className="absolute bottom-0 right-0 h-4 w-4 rounded-full border-2 border-white bg-green-500 animate-pulse" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <h3 className={`font-semibold ${textClass} text-base flex items-center gap-2`}>
                            {contact.username}
                            {contact.status === 'online' && !contact.invisible_mode && (
                              <span className="text-xs text-green-500 font-normal">● online</span>
                            )}
                          </h3>
                          <span className={`text-xs ${contact.unread_count > 0 ? 'text-violet-500 font-semibold' : mutedClass}`}>
                            {contact.last_message_time}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <p className={`text-sm ${mutedClass} flex items-center gap-1`}>
                            {contact.last_message_type === 'sent' && (
                              <CheckCheck className={`h-4 w-4 flex-shrink-0 ${contact.last_message_read ? 'text-blue-500' : ''}`} />
                            )}
                            <span className="line-clamp-1">
                              {contact.last_seen_text && !contact.last_message
                                ? `Last seen ${contact.last_seen_text}` 
                                : contact.last_message || 'Start a conversation'}
                            </span>
                          </p>
                          {contact.unread_count > 0 && (
                            <Badge className="bg-gradient-to-r from-violet-500 to-purple-500 text-white text-xs px-2 py-0.5 rounded-full ml-2 flex-shrink-0">
                              {contact.unread_count}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          )}

          {/* Status Tab */}
          {activeTab === 'status' && (
            <ScrollArea className="h-full">
              <div className="p-3 pb-20">
                {/* My Status */}
                <div className={`flex items-center gap-3 p-3 ${cardClass} rounded-2xl mb-4 cursor-pointer border-2 border-dashed ${borderClass} hover:border-violet-300 transition-colors`}
                  onClick={() => myStatus ? setShowStatusViews(true) : statusInputRef.current?.click()}>
                  <div className="relative">
                    <Avatar className={`h-14 w-14 ${myStatus ? 'ring-2 ring-violet-500' : 'ring-2 ring-gray-300'}`}>
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white">
                        {user.username.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="absolute bottom-0 right-0 w-6 h-6 bg-gradient-to-r from-violet-500 to-purple-500 rounded-full flex items-center justify-center border-2 border-white">
                      <Plus className="h-3 w-3 text-white" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className={`font-semibold ${textClass}`}>My Status</p>
                    <p className={`text-sm ${mutedClass}`}>
                      {myStatus ? `${myStatus.view_count || 0} views • Tap to see` : 'Tap to add status'}
                    </p>
                  </div>
                  {myStatus && myStatus.view_count > 0 && (
                    <div className="flex items-center gap-1 text-violet-500">
                      <Eye className="h-4 w-4" />
                      <span className="text-sm font-medium">{myStatus.view_count}</span>
                    </div>
                  )}
                </div>
                <input type="file" accept="image/*,video/*" className="hidden" ref={statusInputRef}
                  onChange={(e) => { const file = e.target.files?.[0]; if (file) handleAddStatus(file); }} />

                {statuses.length > 0 && (
                  <>
                    <p className={`text-xs font-semibold ${mutedClass} px-2 mb-2 uppercase tracking-wider`}>Recent Updates</p>
                    {statuses.map((status) => (
                      <div key={status.id} className={`flex items-center gap-3 p-3 rounded-xl ${hoverClass} cursor-pointer mb-1 transition-all`}
                        onClick={() => viewStatus(status)}>
                        <Avatar className="h-12 w-12 ring-2 ring-violet-500">
                          <AvatarImage src={status.user_avatar} />
                          <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white">
                            {status.username?.slice(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className={`font-medium ${textClass}`}>{status.username}</p>
                          <p className={`text-xs ${mutedClass}`}>{status.time || 'Just now'}</p>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </ScrollArea>
          )}

          {/* Calls Tab */}
          {activeTab === 'calls' && (
            <ScrollArea className="h-full">
              <div className="pb-20">
                {callHistory.length === 0 ? (
                  <div className={`text-center py-16 ${mutedClass}`}>
                    <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center">
                      <Phone className="h-10 w-10 text-violet-400" />
                    </div>
                    <p className="font-medium text-lg">No calls yet</p>
                    <p className="text-sm mt-1">Start calling your friends!</p>
                  </div>
                ) : (
                  callHistory.map((call, idx) => (
                    <div key={call.id || idx} className={`flex items-center gap-3 px-4 py-3 ${hoverClass} cursor-pointer border-b ${borderClass} transition-all`}>
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={call.contact?.avatar} />
                        <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white">
                          {call.contact?.username?.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className={`font-medium ${textClass}`}>{call.contact?.username}</p>
                        <div className={`flex items-center gap-1 text-sm ${mutedClass}`}>
                          {call.type === 'incoming' && <PhoneIncoming className="h-4 w-4 text-green-500" />}
                          {call.type === 'outgoing' && <PhoneOutgoing className="h-4 w-4 text-blue-500" />}
                          {call.type === 'missed' && <PhoneMissed className="h-4 w-4 text-red-500" />}
                          <span>{call.time}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="text-violet-500 hover:bg-violet-50 rounded-full"
                        onClick={() => initiateCall(call.contact, call.call_type)}>
                        {call.call_type === 'video' ? <Video className="h-5 w-5" /> : <Phone className="h-5 w-5" />}
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          )}

          {/* FAB */}
          <Button
            className="absolute bottom-20 right-4 h-14 w-14 rounded-full bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 shadow-lg shadow-violet-500/30 z-10 transform hover:scale-105 transition-transform"
            onClick={() => {
              if (activeTab === 'chats') setShowAddContact(true);
              else if (activeTab === 'status') statusInputRef.current?.click();
            }}>
            {activeTab === 'chats' && <MessageCircle className="h-6 w-6" />}
            {activeTab === 'status' && <Camera className="h-6 w-6" />}
            {activeTab === 'calls' && <Phone className="h-6 w-6" />}
          </Button>
        </div>

        {/* Bottom Nav */}
        <div className={`${cardClass} border-t ${borderClass} p-2`}>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className={`w-full ${isDark ? 'bg-gray-700' : 'bg-violet-100'} rounded-full p-1 h-12`}>
              <TabsTrigger value="chats" className="flex-1 rounded-full data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500 data-[state=active]:via-purple-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white data-[state=active]:shadow-lg">
                <MessageCircle className="h-5 w-5 mr-1" />Chats
              </TabsTrigger>
              <TabsTrigger value="status" className="flex-1 rounded-full data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500 data-[state=active]:via-purple-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white data-[state=active]:shadow-lg">
                <Clock className="h-5 w-5 mr-1" />Status
              </TabsTrigger>
              <TabsTrigger value="calls" className="flex-1 rounded-full data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500 data-[state=active]:via-purple-500 data-[state=active]:to-indigo-500 data-[state=active]:text-white data-[state=active]:shadow-lg">
                <Phone className="h-5 w-5 mr-1" />Calls
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Chat Area */}
      <div 
        className={`${showMobileChat ? 'flex' : 'hidden md:flex'} flex-col flex-1 ${getThemeBg()}`}
        style={customWallpaper ? { backgroundImage: `url(${customWallpaper})`, backgroundSize: 'cover', backgroundPosition: 'center' } : {}}
      >
        {selectedContact ? (
          <>
            {/* Chat Header */}
            <div className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 text-white p-4 flex items-center gap-3 shadow-lg">
              <Button variant="ghost" size="icon" onClick={() => setShowMobileChat(false)}
                className="md:hidden text-white hover:bg-white/20 rounded-full">
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <Avatar className="h-11 w-11 ring-2 ring-white/30">
                <AvatarImage src={selectedContact.avatar} />
                <AvatarFallback className="bg-white/20 text-white">
                  {selectedContact.username.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="font-semibold">{selectedContact.username}</h2>
                <p className="text-xs text-white/80 flex items-center gap-1">
                  {typing === selectedContact.id ? (
                    <span className="flex items-center gap-1">
                      <span className="flex gap-0.5">
                        <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                        <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                        <span className="w-1.5 h-1.5 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                      </span>
                      typing...
                    </span>
                  ) : selectedContact.status === 'online' && !selectedContact.invisible_mode ? (
                    <><Circle className="h-2 w-2 fill-green-400 text-green-400" /> Online</>
                  ) : selectedContact.last_seen_text ? `Last seen ${selectedContact.last_seen_text}` : 'Offline'}
                </p>
              </div>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 rounded-full"
                onClick={() => initiateCall(selectedContact, 'voice')}><Phone className="h-5 w-5" /></Button>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/20 rounded-full"
                onClick={() => initiateCall(selectedContact, 'video')}><Video className="h-5 w-5" /></Button>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-2 max-w-4xl mx-auto">
                {messages.length === 0 ? (
                  <div className={`text-center py-16 ${mutedClass} ${customWallpaper ? 'bg-black/30 rounded-2xl p-8' : ''}`}>
                    <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center">
                      <Sparkles className="h-12 w-12 text-violet-400" />
                    </div>
                    <p className={`text-lg font-medium ${customWallpaper ? 'text-white' : ''}`}>Start the conversation!</p>
                    <p className={`text-sm mt-1 ${customWallpaper ? 'text-white/70' : ''}`}>Say hello to {selectedContact.username} 👋</p>
                  </div>
                ) : (
                  messages.map((message) => (
                    <div key={message.id} className={`flex ${message.type === 'sent' ? 'justify-end' : 'justify-start'}`}>
                      <Popover open={selectedReaction === message.id} onOpenChange={(open) => setSelectedReaction(open ? message.id : null)}>
                        <PopoverTrigger asChild>
                          <div className={`relative max-w-[70%] rounded-2xl shadow-md cursor-pointer transform hover:scale-[1.01] transition-transform ${
                            message.type === 'sent'
                              ? 'bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 text-white rounded-br-sm'
                              : `${isDark ? 'bg-gray-700 text-white' : 'bg-white text-gray-900'} rounded-bl-sm`
                          }`}>
                            {message.message_type === 'image' && message.media_url && (
                              <img src={message.media_url} alt="" className="rounded-t-2xl max-w-full h-auto max-h-72 object-cover" />
                            )}
                            {message.message_type === 'video' && message.media_url && (
                              <video src={message.media_url} controls className="rounded-t-2xl max-w-full max-h-72" />
                            )}
                            {message.message_type === 'audio' && message.media_url && (
                              <div className="px-4 py-3">
                                <audio src={message.media_url} controls className="w-full h-10" />
                              </div>
                            )}
                            {message.text && <p className="px-4 py-2 text-[15px] leading-relaxed whitespace-pre-wrap">{message.text}</p>}
                            <div className={`px-4 pb-2 flex items-center gap-1 ${message.type === 'sent' ? 'justify-end' : ''}`}>
                              <span className={`text-[11px] ${message.type === 'sent' ? 'text-white/70' : mutedClass}`}>
                                {message.timestamp}
                              </span>
                              {message.type === 'sent' && (
                                message.read ? <CheckCheck className="h-4 w-4 text-blue-300" /> : <Check className="h-4 w-4 text-white/70" />
                              )}
                            </div>
                            {message.reactions?.length > 0 && (
                              <div className={`absolute -bottom-3 ${message.type === 'sent' ? 'left-2' : 'right-2'} flex gap-0.5 ${isDark ? 'bg-gray-600' : 'bg-white'} rounded-full px-1.5 py-0.5 shadow-lg text-sm`}>
                                {[...new Set(message.reactions.map(r => r.reaction))].map(r => <span key={r}>{r}</span>)}
                              </div>
                            )}
                          </div>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-2 flex gap-1 rounded-full" side="top">
                          {REACTIONS.map((r) => (
                            <button key={r.name} onClick={() => handleReaction(message.id, r.emoji)}
                              className="hover:scale-125 transition-transform text-2xl p-1">{r.emoji}</button>
                          ))}
                        </PopoverContent>
                      </Popover>
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Emoji Picker */}
            {showEmojiPicker && (
              <div className="absolute bottom-20 left-4 md:left-[440px] z-50">
                <EmojiPicker onEmojiClick={handleEmojiClick} theme={isDark ? 'dark' : 'light'} width={350} height={400} searchPlaceHolder="Search emoji..." previewConfig={{ showPreview: false }} />
              </div>
            )}

            {/* Input */}
            <div className={`p-4 ${cardClass} border-t ${borderClass}`}>
              <form onSubmit={handleSendMessage} className="flex items-center gap-2 max-w-4xl mx-auto">
                <Button type="button" variant="ghost" size="icon" 
                  className={`${showEmojiPicker ? 'text-violet-500' : mutedClass} hover:text-violet-500 rounded-full`}
                  onClick={() => setShowEmojiPicker(!showEmojiPicker)}>
                  <Smile className="h-6 w-6" />
                </Button>
                
                <input type="file" accept="image/*,video/*" className="hidden" ref={mediaInputRef}
                  onChange={(e) => { const file = e.target.files?.[0]; if (file) handleSendMedia(file, file.type.startsWith('image/') ? 'image' : 'video'); }} />
                <Button type="button" variant="ghost" size="icon" className={`${mutedClass} hover:text-violet-500 rounded-full`}
                  onClick={() => mediaInputRef.current?.click()}><Image className="h-5 w-5" /></Button>
                
                {isRecording ? (
                  <div className="flex-1 flex items-center gap-3 bg-red-50 dark:bg-red-900/20 rounded-full px-4 py-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
                    <span className="text-red-500 font-medium">{formatRecordingTime(recordingTime)}</span>
                    <div className="flex-1" />
                    <Button type="button" variant="ghost" size="icon" onClick={cancelRecording}
                      className="text-red-500 hover:bg-red-100 rounded-full"><X className="h-5 w-5" /></Button>
                    <Button type="button" size="icon" onClick={stopRecording}
                      className="bg-red-500 hover:bg-red-600 rounded-full"><Send className="h-4 w-4" /></Button>
                  </div>
                ) : (
                  <>
                    <Input
                      ref={inputRef}
                      value={newMessage}
                      onChange={(e) => { setNewMessage(e.target.value); handleTypingIndicator(); }}
                      onFocus={() => setShowEmojiPicker(false)}
                      placeholder="Type a message..."
                      className={`flex-1 rounded-full ${isDark ? 'bg-gray-700 border-gray-600' : 'bg-violet-50 border-violet-200'} h-12 text-base px-5 focus:ring-violet-500`}
                    />
                    {newMessage.trim() ? (
                      <Button type="submit" size="icon"
                        className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 rounded-full h-12 w-12 shadow-lg shadow-violet-500/30">
                        <Send className="h-5 w-5" />
                      </Button>
                    ) : (
                      <Button type="button" size="icon" onClick={startRecording}
                        className="bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 hover:from-violet-600 hover:via-purple-600 hover:to-indigo-600 rounded-full h-12 w-12 shadow-lg shadow-violet-500/30">
                        <Mic className="h-5 w-5" />
                      </Button>
                    )}
                  </>
                )}
              </form>
            </div>
          </>
        ) : (
          <div className={`flex-1 flex flex-col items-center justify-center ${mutedClass}`}>
            <div className="relative">
              <GupShupLogo size={160} />
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full flex items-center justify-center animate-bounce">
                <Sparkles className="h-4 w-4 text-white" />
              </div>
            </div>
            <h2 className={`text-3xl font-bold mt-6 ${textClass} bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent`}>
              Welcome to GupShup
            </h2>
            <p className="mt-2 text-center px-4">Select a chat to start messaging<br/>or add new friends</p>
            <Button className="mt-6 bg-gradient-to-r from-violet-500 via-purple-500 to-indigo-500 rounded-full px-6 shadow-lg shadow-violet-500/30" onClick={() => setShowAddContact(true)}>
              <UserPlus className="h-4 w-4 mr-2" /> Add Friends
            </Button>
          </div>
        )}
      </div>

      {/* Dialogs */}
      <Dialog open={showAddContact} onOpenChange={setShowAddContact}>
        <DialogContent className={`max-w-md rounded-3xl ${isDark ? 'bg-gray-800 text-white' : ''}`}>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><UserPlus className="h-5 w-5 text-violet-500" />Add Friend</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input placeholder="Search by username..." onChange={(e) => handleSearchUsers(e.target.value)} className="pl-10 rounded-full" />
            </div>
            <ScrollArea className="max-h-[300px]">
              {searchUsers.map((u) => (
                <div key={u.id} className={`flex items-center gap-3 p-3 rounded-xl ${hoverClass} transition-all`}>
                  <Avatar className="h-11 w-11">
                    <AvatarImage src={u.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white">{u.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className={`font-medium ${textClass}`}>{u.username}</p>
                    <p className={`text-xs ${mutedClass} capitalize flex items-center gap-1`}>
                      {u.status === 'online' ? <><Circle className="h-2 w-2 fill-green-500 text-green-500" /> Online</> : 'Offline'}
                    </p>
                  </div>
                  <Button size="sm" className={`rounded-full ${sendingRequest[u.id] === 'sent' ? 'bg-green-500' : 'bg-gradient-to-r from-violet-500 to-purple-500'}`}
                    onClick={() => handleSendFriendRequest(u.id)} disabled={sendingRequest[u.id]}>
                    {sendingRequest[u.id] === 'sent' ? <Check className="h-4 w-4" /> : 'Add'}
                  </Button>
                </div>
              ))}
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showRequests} onOpenChange={setShowRequests}>
        <DialogContent className={`max-w-md rounded-3xl ${isDark ? 'bg-gray-800 text-white' : ''}`}>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Bell className="h-5 w-5 text-violet-500" />Friend Requests</DialogTitle></DialogHeader>
          <ScrollArea className="max-h-[350px]">
            {friendRequests.length === 0 ? (
              <p className={`text-center ${mutedClass} py-8`}>No pending requests</p>
            ) : (
              friendRequests.map((req) => (
                <div key={req.id} className={`flex items-center gap-3 p-3 ${isDark ? 'bg-gray-700' : 'bg-violet-50'} rounded-xl mb-2`}>
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={req.sender_avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white">{req.sender_username.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className={`font-medium ${textClass}`}>{req.sender_username}</p>
                    <p className={`text-xs ${mutedClass}`}>wants to be your friend</p>
                  </div>
                  <Button size="sm" className="bg-gradient-to-r from-violet-500 to-purple-500 rounded-full h-8 w-8 p-0" onClick={() => handleRespondToRequest(req.id, 'accept')}><Check className="h-4 w-4" /></Button>
                  <Button size="sm" variant="outline" className="rounded-full h-8 w-8 p-0" onClick={() => handleRespondToRequest(req.id, 'reject')}><X className="h-4 w-4" /></Button>
                </div>
              ))
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className={`max-w-md rounded-3xl ${isDark ? 'bg-gray-800 text-white' : ''}`}>
          <DialogHeader><DialogTitle>Profile</DialogTitle></DialogHeader>
          <div className="flex flex-col items-center py-4">
            <div className="relative">
              <Avatar className="h-28 w-28 ring-4 ring-violet-200">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white text-3xl">{user.username.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={(e) => { const file = e.target.files?.[0]; if (file) uploadAvatar(file); }} />
              <Button size="icon" className="absolute bottom-0 right-0 h-9 w-9 rounded-full bg-gradient-to-r from-violet-500 to-purple-500" onClick={() => fileInputRef.current?.click()}><Camera className="h-4 w-4" /></Button>
            </div>
            <h2 className={`text-xl font-bold mt-4 ${textClass}`}>{user.username}</h2>
            <p className={mutedClass}>{user.email}</p>
            <div className="flex gap-2 mt-3">
              <Badge className={`${invisibleMode ? 'bg-gray-200 text-gray-600' : 'bg-gradient-to-r from-green-100 to-emerald-100 text-green-700'} border-0`}>
                {invisibleMode ? <><EyeOff className="h-3 w-3 mr-1" /> Invisible</> : <><Circle className="h-2 w-2 fill-green-500 text-green-500 mr-1" /> Online</>}
              </Badge>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Theme Selector */}
      <Dialog open={showThemeSelector} onOpenChange={setShowThemeSelector}>
        <DialogContent className={`max-w-md rounded-3xl ${isDark ? 'bg-gray-800 text-white' : ''}`}>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Palette className="h-5 w-5 text-violet-500" />Chat Themes</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-5 gap-3">
              {CHAT_THEMES.map((theme) => (
                <button
                  key={theme.id}
                  onClick={() => changeChatTheme(theme.id)}
                  className={`w-12 h-12 rounded-xl ${isDark ? theme.darkBg : theme.bg} border-2 transition-all ${chatTheme === theme.id ? 'border-violet-500 ring-2 ring-violet-500/30' : 'border-transparent'}`}
                  title={theme.name}
                />
              ))}
            </div>
            <div className={`p-4 rounded-xl border-2 border-dashed ${borderClass} text-center cursor-pointer hover:border-violet-300 transition-colors`}
              onClick={() => wallpaperInputRef.current?.click()}>
              <ImageIcon className={`h-8 w-8 mx-auto mb-2 ${mutedClass}`} />
              <p className={`text-sm ${mutedClass}`}>Custom Wallpaper</p>
              <p className={`text-xs ${mutedClass}`}>Choose from gallery</p>
            </div>
            <input type="file" accept="image/*" className="hidden" ref={wallpaperInputRef}
              onChange={(e) => { const file = e.target.files?.[0]; if (file) uploadWallpaper(file); }} />
            {customWallpaper && (
              <div className="relative">
                <img src={customWallpaper} alt="Custom" className="w-full h-32 object-cover rounded-xl" />
                <Button size="sm" variant="destructive" className="absolute top-2 right-2 rounded-full h-8 w-8 p-0"
                  onClick={() => { setCustomWallpaper(null); setChatTheme('default'); }}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Status Views */}
      <Dialog open={showStatusViews} onOpenChange={setShowStatusViews}>
        <DialogContent className={`max-w-md rounded-3xl ${isDark ? 'bg-gray-800 text-white' : ''}`}>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Eye className="h-5 w-5 text-violet-500" />Status Views ({statusViewers.length})</DialogTitle></DialogHeader>
          <ScrollArea className="max-h-[350px]">
            {statusViewers.length === 0 ? (
              <p className={`text-center ${mutedClass} py-8`}>No views yet</p>
            ) : (
              statusViewers.map((viewer, idx) => (
                <div key={viewer.user_id || idx} className={`flex items-center gap-3 p-3 rounded-xl ${hoverClass} mb-1`}>
                  <Avatar className="h-11 w-11">
                    <AvatarImage src={viewer.avatar} />
                    <AvatarFallback className="bg-gradient-to-br from-violet-400 to-purple-500 text-white">{viewer.username?.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className={`font-medium ${textClass}`}>{viewer.username}</p>
                    <p className={`text-xs ${mutedClass}`}>Viewed your status</p>
                  </div>
                  <Eye className={`h-4 w-4 ${mutedClass}`} />
                </div>
              ))
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={showAbout} onOpenChange={setShowAbout}>
        <DialogContent className={`max-w-md rounded-3xl ${isDark ? 'bg-gray-800 text-white' : ''}`}>
          <div className="text-center py-6">
            <GupShupLogo size={80} className="mx-auto mb-4" />
            <h2 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">GupShup Chat</h2>
            <p className={`${mutedClass} mt-1`}>Connect, Chat, Share</p>
            <p className={`text-xs ${mutedClass} mt-1`}>Version 2.0.0</p>
            <div className={`mt-4 p-3 rounded-xl ${isDark ? 'bg-gray-700' : 'bg-violet-50'}`}>
              <p className="text-sm font-medium text-violet-600 mb-2">✨ Features</p>
              <div className="grid grid-cols-2 gap-2 text-xs text-left">
                <span>✅ Real-time Chat</span><span>✅ Voice Messages</span>
                <span>✅ Video Calls</span><span>✅ Photo/Video Share</span>
                <span>✅ Push Notifications</span><span>✅ Message Sounds</span>
                <span>✅ Invisible Mode</span><span>✅ Chat Themes</span>
                <span>✅ Status Views</span><span>✅ Data Persistence</span>
              </div>
            </div>
            <div className={`mt-6 pt-4 border-t ${borderClass}`}>
              <p className={`text-sm font-medium ${mutedClass} mb-3`}>Developed with ❤️ by</p>
              <div className="flex justify-center gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-violet-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-2"><User className="h-6 w-6 text-violet-600" /></div>
                  <p className={`text-sm font-medium ${textClass}`}>Rahman Ahmed</p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-full flex items-center justify-center mx-auto mb-2"><User className="h-6 w-6 text-purple-600" /></div>
                  <p className={`text-sm font-medium ${textClass}`}>Ghulam Murtaza</p>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!showStatusView} onOpenChange={() => setShowStatusView(null)}>
        <DialogContent className="max-w-lg rounded-3xl p-0 overflow-hidden">
          <div className="relative bg-black min-h-[500px] flex items-center justify-center">
            {showStatusView?.media_url && (
              showStatusView.media_type === 'video' 
                ? <video src={showStatusView.media_url} controls autoPlay className="max-w-full max-h-[500px]" />
                : <img src={showStatusView.media_url} alt="Status" className="max-w-full max-h-[500px] object-contain" />
            )}
            <div className="absolute top-4 left-4 flex items-center gap-2">
              <Avatar className="h-10 w-10 ring-2 ring-white">
                <AvatarImage src={showStatusView?.user_avatar} />
                <AvatarFallback className="bg-gradient-to-br from-violet-500 to-purple-500 text-white">{showStatusView?.username?.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="text-white">
                <p className="font-medium text-sm">{showStatusView?.username}</p>
                <p className="text-xs opacity-80">{showStatusView?.time}</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ChatPage;
