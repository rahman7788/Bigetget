import React from 'react';

const GupShupLogo = ({ size = 40, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Main gradient - Purple/Violet theme */}
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#8b5cf6" />
          <stop offset="50%" stopColor="#a855f7" />
          <stop offset="100%" stopColor="#6366f1" />
        </linearGradient>
        
        {/* Bubble gradient */}
        <linearGradient id="bubbleGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#f3e8ff" />
        </linearGradient>
        
        <linearGradient id="bubbleGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fdf4ff" />
          <stop offset="100%" stopColor="#ffffff" />
        </linearGradient>
        
        {/* Glow effect */}
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
          <feMerge>
            <feMergeNode in="coloredBlur"/>
            <feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
        
        <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
          <feDropShadow dx="0" dy="3" stdDeviation="4" floodColor="#8b5cf6" floodOpacity="0.3"/>
        </filter>
      </defs>
      
      {/* Main circle background */}
      <circle cx="50" cy="50" r="48" fill="url(#logoGradient)" filter="url(#shadow)" />
      
      {/* Decorative ring */}
      <circle cx="50" cy="50" r="44" fill="none" stroke="white" strokeWidth="0.5" opacity="0.3" />
      
      {/* Chat bubble 1 (left/back) */}
      <path
        d="M20 32 Q20 24 28 24 L46 24 Q54 24 54 32 L54 46 Q54 54 46 54 L32 54 L24 62 L24 54 L28 54 Q20 54 20 46 Z"
        fill="url(#bubbleGradient1)"
        opacity="0.95"
        filter="url(#glow)"
      />
      
      {/* Chat bubble 2 (right/front) */}
      <path
        d="M46 38 Q46 30 54 30 L72 30 Q80 30 80 38 L80 52 Q80 60 72 60 L76 60 L76 68 L68 60 L54 60 Q46 60 46 52 Z"
        fill="url(#bubbleGradient2)"
        filter="url(#glow)"
      />
      
      {/* Modern dots in bubble 1 */}
      <circle cx="29" cy="39" r="3" fill="#8b5cf6" />
      <circle cx="37" cy="39" r="3" fill="#a855f7" />
      <circle cx="45" cy="39" r="3" fill="#6366f1" />
      
      {/* Heart icon in bubble 2 (showing love/connection) */}
      <path
        d="M63 42 C63 40 65 38 67 38 C69 38 71 40 71 42 C71 40 73 38 75 38 C77 38 79 40 79 42 C79 46 71 52 71 52 C71 52 63 46 63 42"
        fill="#ec4899"
        opacity="0.9"
      />
      
      {/* Sparkle effects */}
      <circle cx="16" cy="72" r="3" fill="white" opacity="0.4" />
      <circle cx="84" cy="22" r="2.5" fill="white" opacity="0.5" />
      <circle cx="78" cy="76" r="2" fill="white" opacity="0.3" />
      <circle cx="22" cy="20" r="1.5" fill="white" opacity="0.4" />
      
      {/* Star sparkle */}
      <path d="M86 45 L87 48 L90 48 L88 50 L89 53 L86 51 L83 53 L84 50 L82 48 L85 48 Z" fill="white" opacity="0.6" />
    </svg>
  );
};

export const GupShupLogoText = ({ size = 'md', dark = false }) => {
  const sizes = {
    sm: { logo: 32, text: 'text-lg' },
    md: { logo: 40, text: 'text-xl' },
    lg: { logo: 56, text: 'text-3xl' },
    xl: { logo: 72, text: 'text-4xl' }
  };
  
  const s = sizes[size] || sizes.md;
  
  return (
    <div className="flex items-center gap-2">
      <GupShupLogo size={s.logo} />
      <span 
        className={`font-bold ${s.text} ${dark ? 'text-white' : 'bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent'}`}
        style={{ fontFamily: 'Poppins, sans-serif' }}
      >
        GupShup
      </span>
    </div>
  );
};

export default GupShupLogo;
